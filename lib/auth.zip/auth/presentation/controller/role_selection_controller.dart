import 'package:get/get.dart';

class RoleSelectionController extends GetxController {
  final selectedRole = Rx<String?>(null);

  void selectRole(String role) {
    selectedRole.value = role;
  }

  void navigateBasedOnRole() {
    switch (selectedRole.value) {
      case 'request_help':
        // Navigate to request help flow
        Get.toNamed('/requestHelp');
        break;
      case 'volunteer':
        // Navigate to volunteer onboarding or main app
        Get.toNamed('/adminVerification');
        break;
      case 'admin':
        // Navigate to admin verification form
        Get.toNamed('/adminPanel');
        break;
    }
  }
}
