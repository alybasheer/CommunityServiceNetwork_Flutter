class ApiNames {
  static const baseUrl = 'http://localhost:8989/';
  static const signup = 'authentication/signup';
}
